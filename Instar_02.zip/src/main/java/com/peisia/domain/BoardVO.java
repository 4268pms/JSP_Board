package com.peisia.domain;

import lombok.Data;

@Data
public class BoardVO {
    /* 게시판 번호 */
    private int s_num;
    
    /* 게시판 제목 */
    private String s_title;
    
    /* 게시판 내용 */
    private String s_content;
    
    /* 게시판 작가 */
    private String s_id;
    
    /* 게시판 사진 */
    private String s_img;
    /* 총 게시글 수*/
    private String total;
    /* 등록 날짜 */
	/* private Date regdate; */
    
    /* 수정 날짜 */
	/* private Date updateDate; */
}

/*
 * num int primary key auto_increment, 
 * s_title char(255),
 *  s_content text, 
 *  s_id
 * char(30)
 */