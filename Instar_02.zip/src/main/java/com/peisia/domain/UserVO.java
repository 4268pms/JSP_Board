package com.peisia.domain;


import lombok.Data;

@Data
public class UserVO {
	private String userE_mail;
	private String userName;
	private String userID;
	private String userPassword;
	private String userImg;
}
