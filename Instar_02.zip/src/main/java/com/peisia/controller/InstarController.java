package com.peisia.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.peisia.domain.BoardVO;
import com.peisia.domain.UserVO;
import com.peisia.service.GuestService;

import lombok.extern.log4j.Log4j;

@Log4j
@RequestMapping("/guest/*")
//@AllArgsConstructor
@Controller
public class InstarController {

	
	private GuestService service;

	/* 홈 페이지 */
	/* 게시판 목록 페이지 접속 */
	@GetMapping("/home")
	public void home(@RequestParam("currentPage") int currentPage, Model model) {
		log.info("=====홈 페이지 진입=====");
		model.addAttribute("list", service.getList(currentPage));
		/* 전체 게시글 수 */
		model.addAttribute("total", service.getListCount());

	}

	/* 게시판 페이지 */
	@GetMapping("/write")
	public String write() {
		log.info("=====글쓰기 페이지 진입=====");
		return null;
	}

	/* 게시판 등록 */
	@PostMapping("/write")
	public String boardEnrollPOST(BoardVO board) {
		log.info("BoardVO:" + board);
		service.write(board);
		return "redirect:/guest/home?currentPage=1";
	}

	/* 게시판 조회 */
	@GetMapping({ "/get", "/modify" })
	public void boardGetPageGET(int s_num, Model model) {
		log.info("게시판 조회");
		model.addAttribute("pageInfo", service.getPage(s_num));
	}

	@PostMapping("/modify")
	public String boardModifyPOST(BoardVO board) {
		service.modify(board);
		return "redirect:/guest/home?currentPage=1";
	}

	/* 페이지 삭제 */
	@GetMapping("/del")
	public String del(int s_num) {
		log.info("컨트롤러 ==== 글번호 ===============" + s_num);
		service.del(s_num);
		return "redirect:/guest/home?currentPage=1"; // 책 p.245 참고
	}
	/* ========== 회원 ========== */
	/* 회원가입 페이지 */
	@GetMapping({"/join","/logininfo"})
	public String join() {
		log.info("=====회원가입 or 인포 페이지 진입=====");
		return null;
	}
	/* 회원가입 */
	@PostMapping("/join")
	public String join(UserVO user) {
		log.info("=======회원가입 성공========UserVO:" + user);
		service.join(user);
		return "redirect:/guest/login";
		}
	/* 로그인 페이지 */
	@GetMapping("/login")
	public void login() {
		log.info("=====로그인 페이지 진입=====");
	}
	/* 로그인 확인 */
	@GetMapping("/login_ok")
	public String login_ok(String mail, Model model) {
		model.addAttribute("login",service.login(mail));
		log.info("컨트롤러 ==== 로그인 회원 "+mail);
		return null;
		/* return "redirect:/guest/home?currentPage=1"; */
	}
	/* 로그인한 회원 글리스트*/
	/*
	 * @GetMapping("/logininfo") public void loginInfo(String s_id, Model model) {
	 * model.addAttribute("loginInfolist",service.getInfolist(s_id));
	 * log.info("컨트롤러 ==== 로그인 회원 "+s_id); }
	 */
	
	

	public GuestService getService() {
		return service;
	}

	public void setService(GuestService service) {
		this.service = service;
	}
}
