package com.peisia.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.peisia.domain.BoardVO;
import com.peisia.domain.UserVO;
import com.peisia.mapper.GuestMapper;

import lombok.Setter;

@Service
//@AllArgsConstructor
public class GuestServiceImpl implements GuestService {

	@Setter(onMethod_ = @Autowired)
	private GuestMapper mapper;

	/* ==========게시글========== */
	/* 게시판 등록 */
	@Override
	public void write(BoardVO board) {
		mapper.write(board);
	}

	/* 게시판 리스트 */
	@Override
	public List<BoardVO> getList(int currentPage) {
		int limitIndex = (currentPage - 1) * 3;
		return mapper.getList(limitIndex);
	}

	/* 글 리스트 전체 */
	@Override
	public List<BoardVO> getListCount() {
		return mapper.getListCount();
	}

	/* 게시판 조회 */
	@Override
	public BoardVO getPage(int s_num) {

		return mapper.getPage(s_num);
	}

	/* 게시판 수정 */
	@Override
	public int modify(BoardVO board) {
		mapper.modify(board);
		return mapper.modify(board);
	}

	@Override
	public void del(int s_num) {
		mapper.del(s_num);
	}

	/* ==========회원========== */
	/* 회원 가입 */
	@Override
	public void join(UserVO user) {
		mapper.join(user);
	}

	/* 로그인 */
	@Override
	public UserVO login(String mail) {
		return mapper.login(mail);
	}
	/* 마이페이지 (쓴 글) */
	/*
	 * @Override public List<BoardVO> getInfolist(String s_id) {
	 * 
	 * return mapper.getInfolist(s_id); }
	 */
}
