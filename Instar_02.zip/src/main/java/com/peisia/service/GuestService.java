package com.peisia.service;

import java.util.List;

import com.peisia.domain.BoardVO;
import com.peisia.domain.UserVO;

public interface GuestService {
	/* ==========게시글========== */
	/* 게시판 등록 */
	public void write(BoardVO board);

	/* 게시글 리스트 */
	public List<BoardVO> getList(int currentPage);

	/* 전체 글 리스트 */
	public List<BoardVO> getListCount();

	/* 게시판 조회 */
	public BoardVO getPage(int s_num);

	/* 게시판 수정 */
	public int modify(BoardVO board);

	/* 게시판 삭제 */
	public void del(int s_num);

	/* ==========회원========== */
	/* 회원 가입 */
	public void join(UserVO user);

	/* 로그인 */
	public UserVO login(String mail);
	/* 마이페이지 (쓴 글) */
	/* public List<BoardVO> getInfolist(String s_id); */
}
